export enum EnumEventDefine {
    openResultView = "openResultView",
}