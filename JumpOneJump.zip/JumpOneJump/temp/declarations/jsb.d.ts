/// <reference path="G:\CocosDashboard\resources\.editors\Creator\3.5.2\resources\resources\3d\engine\@types\jsb.d.ts"/>
