System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, v3, GameConst, _crd;

  _export("GameConst", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      v3 = _cc.v3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "644bfPCJ0lL2L4vuu7k/x7s", "GameConst", undefined);

      _export("GameConst", GameConst = class GameConst {});

      GameConst.minBricklySpace = 1.2;
      GameConst.maxBricklySpace = 3;
      GameConst.cameraXOZforward = v3(-1, 0, -1).normalize();
      GameConst.cameraHorizontalDistance = 8;
      GameConst.cameraVerticallDistance = 6;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2807fb56b570288d20353a55a8cfb08fd20f8e83.js.map