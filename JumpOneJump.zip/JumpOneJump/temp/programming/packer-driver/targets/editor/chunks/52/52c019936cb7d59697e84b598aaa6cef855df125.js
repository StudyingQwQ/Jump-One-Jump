System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _crd, ccclass, property, GameConst;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "644bfPCJ0lL2L4vuu7k/x7s", "GameConst", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameConst", GameConst = (_dec = ccclass('GameConst'), _dec(_class = class GameConst extends Component {
        start() {}

        update(deltaTime) {}

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=52c019936cb7d59697e84b598aaa6cef855df125.js.map