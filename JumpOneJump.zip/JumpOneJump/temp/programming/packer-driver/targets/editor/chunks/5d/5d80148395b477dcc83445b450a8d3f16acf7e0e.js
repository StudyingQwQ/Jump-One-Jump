System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, log, Label, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, EGameStatus, GameMgr;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export("EGameStatus", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      log = _cc.log;
      Label = _cc.Label;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "48063LIVQNLdZuSiTjjYldY", "GameMgr", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      (function (EGameStatus) {
        EGameStatus[EGameStatus["wait"] = 1] = "wait";
        EGameStatus[EGameStatus["idle"] = 2] = "idle";
        EGameStatus[EGameStatus["start_jump"] = 3] = "start_jump";
        EGameStatus[EGameStatus["jumping"] = 4] = "jumping";
        EGameStatus[EGameStatus["die"] = 5] = "die";
      })(EGameStatus || _export("EGameStatus", EGameStatus = {}));

      _export("GameMgr", GameMgr = (_dec = ccclass('GameMgr'), _dec2 = property(Label), _dec(_class = (_class2 = class GameMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lb_debug", _descriptor, this);

          this._gameStatus = EGameStatus.wait;
        }

        set gameStatus(status) {
          switch (status) {
            case EGameStatus.wait:
              {
                log('�ȴ�');
                break;
              }

            case EGameStatus.idle:
              {
                log('����');
                break;
              }

            case EGameStatus.start_jump:
              {
                log('����');
                break;
              }

            case EGameStatus.jumping:
              {
                log('����');
                break;
              }

            case EGameStatus.die:
              {
                log('����');
                break;
              }
          }

          this._gameStatus = status;
          this.lb_debug.string = `gameStatus:${status}`;
        }

        get gameStatus() {
          return this._gameStatus;
        }

        start() {
          // ��ʼ��״̬
          this.gameStatus = EGameStatus.wait;
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lb_debug", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=5d80148395b477dcc83445b450a8d3f16acf7e0e.js.map