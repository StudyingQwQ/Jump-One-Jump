System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd, EnumEventDefine;

  _export("EnumEventDefine", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fa38a6PmBZFcJzEjSaM/99w", "EventDefine", undefined);

      (function (EnumEventDefine) {
        EnumEventDefine["openResultView"] = "openResultView";
      })(EnumEventDefine || _export("EnumEventDefine", EnumEventDefine = {}));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7bcca37dec6392c6ad60eb3425b6fcd041400d2e.js.map