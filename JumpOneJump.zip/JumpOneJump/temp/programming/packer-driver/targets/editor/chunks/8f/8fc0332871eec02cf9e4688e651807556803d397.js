System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, log, Label, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, EGameStatus, GameMgr;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export("EGameStatus", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      log = _cc.log;
      Label = _cc.Label;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "48063LIVQNLdZuSiTjjYldY", "GameMgr", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      (function (EGameStatus) {
        EGameStatus[EGameStatus["wait"] = 1] = "wait";
        EGameStatus[EGameStatus["idle"] = 2] = "idle";
        EGameStatus[EGameStatus["start_jump"] = 3] = "start_jump";
        EGameStatus[EGameStatus["jumping"] = 4] = "jumping";
        EGameStatus[EGameStatus["die"] = 5] = "die";
      })(EGameStatus || _export("EGameStatus", EGameStatus = {}));

      _export("GameMgr", GameMgr = (_dec = ccclass('GameMgr'), _dec2 = property(Label), _dec3 = property(Node), _dec(_class = (_class2 = class GameMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lb_debug", _descriptor, this);

          _initializerDefineProperty(this, "nd_touch", _descriptor2, this);

          this._gameStatus = EGameStatus.wait;
        }

        set gameStatus(status) {
          switch (status) {
            case EGameStatus.wait:
              {
                log('�ȴ�'); //todo ����ש��

                this.scheduleOnce(() => {
                  this.gameStatus = EGameStatus.idle;
                }, 1);
                break;
              }

            case EGameStatus.idle:
              {
                log('����');
                break;
              }

            case EGameStatus.start_jump:
              {
                log('����');
                break;
              }

            case EGameStatus.jumping:
              {
                log('����'); //todo �ж����������

                this.scheduleOnce(() => {
                  this.gameStatus = EGameStatus.wait;
                }, 1);
                break;
              }

            case EGameStatus.die:
              {
                log('����');
                break;
              }
          }

          this._gameStatus = status;
          this.lb_debug.string = `gameStatus:${this.gameStatus}`;
        }

        get gameStatus() {
          return this._gameStatus;
        }

        start() {
          // ��ʼ��״̬
          this.gameStatus = EGameStatus.wait; //ע�ᴥ���¼�

          this.nd_touch.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
          this.nd_touch.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        }

        onTouchStart(evt) {
          if (this.gameStatus == EGameStatus.idle) {
            this.gameStatus = EGameStatus.start_jump;
          }
        }

        onTouchEnd(evt) {
          if (this.gameStatus == EGameStatus.start_jump) {
            this.gameStatus = EGameStatus.jumping;
          }
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lb_debug", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "nd_touch", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8fc0332871eec02cf9e4688e651807556803d397.js.map