System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, log, Label, Prefab, v3, instantiate, math, Camera, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, EGameStatus, GameMgr;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export("EGameStatus", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      log = _cc.log;
      Label = _cc.Label;
      Prefab = _cc.Prefab;
      v3 = _cc.v3;
      instantiate = _cc.instantiate;
      math = _cc.math;
      Camera = _cc.Camera;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "48063LIVQNLdZuSiTjjYldY", "GameMgr", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      (function (EGameStatus) {
        EGameStatus[EGameStatus["wait"] = 1] = "wait";
        EGameStatus[EGameStatus["idle"] = 2] = "idle";
        EGameStatus[EGameStatus["start_jump"] = 3] = "start_jump";
        EGameStatus[EGameStatus["jumping"] = 4] = "jumping";
        EGameStatus[EGameStatus["die"] = 5] = "die";
      })(EGameStatus || _export("EGameStatus", EGameStatus = {}));

      _export("GameMgr", GameMgr = (_dec = ccclass('GameMgr'), _dec2 = property(Label), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Prefab), _dec6 = property(Prefab), _dec7 = property(Camera), _dec(_class = (_class2 = class GameMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lb_debug", _descriptor, this);

          _initializerDefineProperty(this, "nd_touch", _descriptor2, this);

          _initializerDefineProperty(this, "nd_scene", _descriptor3, this);

          _initializerDefineProperty(this, "pb_brick", _descriptor4, this);

          _initializerDefineProperty(this, "pb_role", _descriptor5, this);

          _initializerDefineProperty(this, "camera", _descriptor6, this);

          this._nextBrickPos = v3();
          this._role = void 0;
          this._allbricks = [];
          this._gameStatus = EGameStatus.wait;
        }

        set gameStatus(status) {
          switch (status) {
            case EGameStatus.wait:
              {
                log('�ȴ�');
                this.createBrick();
                this.moveCamera();
                this.scheduleOnce(() => {
                  this.gameStatus = EGameStatus.idle;
                }, 0.2);
                break;
              }

            case EGameStatus.idle:
              {
                log('����');
                break;
              }

            case EGameStatus.start_jump:
              {
                log('����');
                break;
              }

            case EGameStatus.jumping:
              {
                log('����'); //todo �ж����������

                this.scheduleOnce(() => {
                  this.gameStatus = EGameStatus.wait;
                }, 1);
                break;
              }

            case EGameStatus.die:
              {
                log('����');
                break;
              }
          }

          this._gameStatus = status;
          this.lb_debug.string = `gameStatus:${this.gameStatus}`;
        }

        get gameStatus() {
          return this._gameStatus;
        }

        start() {
          //�ȴ���һ��ש��
          this.createBrick(); //��ʼ����ɫ

          this.initRole(); // ��ʼ��״̬

          this.gameStatus = EGameStatus.wait; //ע�ᴥ���¼�

          this.nd_touch.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
          this.nd_touch.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        }

        onTouchStart(evt) {
          if (this.gameStatus == EGameStatus.idle) {
            this.gameStatus = EGameStatus.start_jump;
          }
        }

        onTouchEnd(evt) {
          if (this.gameStatus == EGameStatus.start_jump) {
            this.gameStatus = EGameStatus.jumping;
          }
        } // ����ש��


        createBrick() {
          const nextBrickPos = v3(); // ��ȡǰһ��שͷ

          const lastBrick = this._allbricks[this._allbricks.length - 1];

          if (lastBrick) {
            nextBrickPos.set(lastBrick.position);
            const movestep = math.randomRange(-6, -1); // ����� x,z ��

            if (Math.random() < 0.5) {
              nextBrickPos.add3f(0, 0, movestep);
            } else {
              nextBrickPos.add3f(movestep, 0, 0);
            }
          }

          const brick = instantiate(this.pb_brick);
          this.nd_scene.addChild(brick);
          brick.setPosition(nextBrickPos);

          this._allbricks.push(brick); // �������5�����Ƴ���һ��


          if (this._allbricks.length > 5) {
            this._allbricks.shift().destroy();
          }
        } //�ƶ����


        moveCamera() {
          const midPos = v3(); // ���ͶӰ��xoz��ĳ�����

          const cameraXOZforward = v3(-1, 0, -1).normalize();
          const length_bricks = this._allbricks.length;

          if (length_bricks > 1) {
            // �м�λ�ã�ȡ�������
            Vec3.add(midPos, this._allbricks[length_bricks - 1].position, this._allbricks[length_bricks - 2].position).multiplyScalar(0.5);
          } // ���ͶӰ��xoz��ͶӰ��


          const cameraXOZpos = Vec3.subtract(v3(), midPos, cameraXOZforward.multiplyScalar(15)); // �����Ŀ��λ��

          const cameraTargetPos = Vec3.add(v3(), cameraXOZpos, v3(0, 10, 0));
          tween(this.camera.node).to(0.2, {
            position: cameraTargetPos
          }, {
            easing: 'sineOutIn'
          }).call(() => {
            this.camera.node.lookAt(midPos);
          }).start();
        } // ��ʼ����ɫ


        initRole() {
          this._role = instantiate(this.pb_role);
          this.nd_scene.addChild(this._role); // ��ȡ��һ��שͷ

          const firstBrick = this._allbricks[0];

          if (firstBrick) {
            const firstPos = firstBrick.getPosition();

            this._role.setPosition(firstPos.x, 0.5, firstPos.z);
          }
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lb_debug", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "nd_touch", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "nd_scene", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "pb_brick", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "pb_role", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "camera", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ab3e38dfe328b01158b95a2b3080bd9d86776dca.js.map