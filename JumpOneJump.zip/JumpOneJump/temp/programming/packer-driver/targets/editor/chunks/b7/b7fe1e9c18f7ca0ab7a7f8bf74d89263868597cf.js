System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, director, _dec, _class, _crd, ccclass, property, ResultViewCtl;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "bd301fgCIVFdoTH7RN+4hb7", "ResultViewCtl", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ResultViewCtl", ResultViewCtl = (_dec = ccclass('ResultViewCtl'), _dec(_class = class ResultViewCtl extends Component {
        start() {}

        playAgain() {
          this.node.active = false; //���¿�ʼ��Ϸ

          director.loadScene("game");
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b7fe1e9c18f7ca0ab7a7f8bf74d89263868597cf.js.map