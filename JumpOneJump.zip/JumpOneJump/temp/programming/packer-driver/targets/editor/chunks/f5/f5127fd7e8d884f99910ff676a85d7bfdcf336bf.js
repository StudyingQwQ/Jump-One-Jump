System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _crd, ccclass, property, GameViewCtl;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "66f4at2o0NATZY4NZXSh0Mh", "GameViewCtl", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameViewCtl", GameViewCtl = (_dec = ccclass('GameViewCtl'), _dec(_class = class GameViewCtl extends Component {
        start() {}

        update(deltaTime) {}

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=f5127fd7e8d884f99910ff676a85d7bfdcf336bf.js.map