System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _crd, ccclass, property, GoToSceneHelper;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "e7e34O4Wb9OmbWLcTB+49A2", "GoToSceneHelper", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GoToSceneHelper", GoToSceneHelper = (_dec = ccclass('GoToSceneHelper'), _dec(_class = class GoToSceneHelper extends Component {
        start() {}

        update(deltaTime) {}

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ff99dd19345892762d28a7ecfce828c293a6d39f.js.map