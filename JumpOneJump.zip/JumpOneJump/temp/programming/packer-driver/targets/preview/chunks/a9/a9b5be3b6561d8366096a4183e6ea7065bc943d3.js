System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, log, Label, Prefab, v3, instantiate, math, Camera, Vec3, tween, game, Vec2, v2, EnumEventDefine, GameViewCtl, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, EGameStatus, GameMgr;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEnumEventDefine(extras) {
    _reporterNs.report("EnumEventDefine", "./EventDefine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameViewCtl(extras) {
    _reporterNs.report("GameViewCtl", "./GameViewCtl", _context.meta, extras);
  }

  _export("EGameStatus", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      log = _cc.log;
      Label = _cc.Label;
      Prefab = _cc.Prefab;
      v3 = _cc.v3;
      instantiate = _cc.instantiate;
      math = _cc.math;
      Camera = _cc.Camera;
      Vec3 = _cc.Vec3;
      tween = _cc.tween;
      game = _cc.game;
      Vec2 = _cc.Vec2;
      v2 = _cc.v2;
    }, function (_unresolved_2) {
      EnumEventDefine = _unresolved_2.EnumEventDefine;
    }, function (_unresolved_3) {
      GameViewCtl = _unresolved_3.GameViewCtl;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "48063LIVQNLdZuSiTjjYldY", "GameMgr", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      (function (EGameStatus) {
        EGameStatus[EGameStatus["wait"] = 1] = "wait";
        EGameStatus[EGameStatus["idle"] = 2] = "idle";
        EGameStatus[EGameStatus["start_jump"] = 3] = "start_jump";
        EGameStatus[EGameStatus["jumping"] = 4] = "jumping";
        EGameStatus[EGameStatus["die"] = 5] = "die";
      })(EGameStatus || _export("EGameStatus", EGameStatus = {}));

      _export("GameMgr", GameMgr = (_dec = ccclass('GameMgr'), _dec2 = property(_crd && GameViewCtl === void 0 ? (_reportPossibleCrUseOfGameViewCtl({
        error: Error()
      }), GameViewCtl) : GameViewCtl), _dec3 = property(Label), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Prefab), _dec7 = property(Prefab), _dec8 = property(Camera), _dec(_class = (_class2 = class GameMgr extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "gameviewCtl", _descriptor, this);

          _initializerDefineProperty(this, "lb_debug", _descriptor2, this);

          _initializerDefineProperty(this, "nd_touch", _descriptor3, this);

          _initializerDefineProperty(this, "nd_scene", _descriptor4, this);

          _initializerDefineProperty(this, "pb_brick", _descriptor5, this);

          _initializerDefineProperty(this, "pb_role", _descriptor6, this);

          _initializerDefineProperty(this, "camera", _descriptor7, this);

          this._allbricks = [];
          this._role = void 0;
          this._jumpingTime = 0;
          this._gameStatus = EGameStatus.wait;
        }

        set gameStatus(status) {
          switch (status) {
            case EGameStatus.wait:
              {
                log('�ȴ�');
                this.createBrick();
                this.moveCamera();
                this.scheduleOnce(() => {
                  this.gameStatus = EGameStatus.idle;
                }, 0.2);
                break;
              }

            case EGameStatus.idle:
              {
                log('����');
                break;
              }

            case EGameStatus.start_jump:
              {
                log('����');
                this._jumpingTime = Date.now();
                break;
              }

            case EGameStatus.jumping:
              {
                log('����');
                this._jumpingTime = Date.now() - this._jumpingTime; // �ƶ���ɫ

                this.moveRole();
                break;
              }

            case EGameStatus.die:
              {
                log('����');
                game.emit((_crd && EnumEventDefine === void 0 ? (_reportPossibleCrUseOfEnumEventDefine({
                  error: Error()
                }), EnumEventDefine) : EnumEventDefine).openResultView);
                break;
              }
          }

          this._gameStatus = status;
          this.lb_debug.string = "gameStatus:" + this.gameStatus;
        }

        get gameStatus() {
          return this._gameStatus;
        }

        start() {
          this.gameviewCtl.score = 0; // �ȴ���һ��ש��

          this.createBrick(); // ��ʼ����ɫ

          this.initRole(); // ��ʼ��״̬

          this.gameStatus = EGameStatus.wait; //ע�ᴥ���¼�

          this.nd_touch.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
          this.nd_touch.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        }

        onTouchStart(evt) {
          if (this.gameStatus == EGameStatus.idle) {
            this.gameStatus = EGameStatus.start_jump;
          }
        }

        onTouchEnd(evt) {
          if (this.gameStatus == EGameStatus.start_jump) {
            this.gameStatus = EGameStatus.jumping;
          }
        } // ��ʼ����ɫ


        initRole() {
          this._role = instantiate(this.pb_role);
          this.nd_scene.addChild(this._role); // ��ȡ��һ��שͷ

          var firstBrick = this._allbricks[0];

          if (firstBrick) {
            var firstPos = firstBrick.getPosition();

            this._role.setPosition(firstPos.x, 0.5, firstPos.z);
          }
        } // ����ש��


        createBrick() {
          var nextBrickPos = v3(); // ��ȡǰһ��שͷ

          var lastBrick = this._allbricks[this._allbricks.length - 1];

          if (lastBrick) {
            nextBrickPos.set(lastBrick.position);
            var movestep = math.randomRange(-6, -1); // ����� x,z ��

            if (Math.random() < 0.5) {
              nextBrickPos.add3f(0, 0, movestep);
            } else {
              nextBrickPos.add3f(movestep, 0, 0);
            }
          }

          var brick = instantiate(this.pb_brick);
          this.nd_scene.addChild(brick);
          brick.setPosition(nextBrickPos);

          this._allbricks.push(brick); // �������5�����Ƴ���һ��


          if (this._allbricks.length > 5) {
            this._allbricks.shift().destroy();
          }
        } //�ƶ����


        moveCamera() {
          var midPos = v3(); // ���ͶӰ��xoz��ĳ�����

          var cameraXOZforward = v3(-1, 0, -1).normalize();
          var length_bricks = this._allbricks.length;

          if (length_bricks > 1) {
            // �м�λ�ã�ȡ�������
            Vec3.add(midPos, this._allbricks[length_bricks - 1].position, this._allbricks[length_bricks - 2].position).multiplyScalar(0.5);
          } // ���ͶӰ��xoz��ͶӰ��


          var cameraXOZpos = Vec3.subtract(v3(), midPos, cameraXOZforward.multiplyScalar(15)); // �����Ŀ��λ��

          var cameraTargetPos = Vec3.add(v3(), cameraXOZpos, v3(0, 10, 0));
          tween(this.camera.node).to(0.2, {
            position: cameraTargetPos
          }, {
            easing: 'sineOutIn'
          }).call(() => {
            this.camera.node.lookAt(midPos);
          }).start();
        } //�ƶ���ɫ


        moveRole() {
          // ������100-3000������
          this._jumpingTime = math.clamp(this._jumpingTime, 100, 3000); // �ƶ�����

          var moveDir = v3();
          var length_bricks = this._allbricks.length;

          if (length_bricks > 1) {
            // ����������������һ��
            Vec3.subtract(moveDir, this._allbricks[length_bricks - 1].position, this._allbricks[length_bricks - 2].position).normalize();
          } // ����ʱ�����ƶ��ľ���


          moveDir.multiplyScalar(this._jumpingTime / 1000 * 6);
          tween(this._role).by(0.5, {
            position: moveDir
          }).delay(0.1).call(() => {
            // ��ȡ���һ��שͷ
            var lastBrick = this._allbricks[this._allbricks.length - 1];

            if (lastBrick) {
              //������xozͶӰ������
              var roleXOZPos = v2(this._role.position.x, this._role.position.z);
              var brickXOZPos = v2(lastBrick.position.x, lastBrick.position.z); // ����ˮƽ�����

              var distance = Vec2.distance(roleXOZPos, brickXOZPos);

              if (distance < 0.5) {
                // ����С���� �ɹ�
                this.gameStatus = EGameStatus.wait;
                this.gameviewCtl.score++;
              } else {
                this.gameStatus = EGameStatus.die;
              }
            } else {
              this.gameStatus = EGameStatus.die;
            }
          }).start();
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gameviewCtl", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lb_debug", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "nd_touch", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "nd_scene", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "pb_brick", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "pb_role", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "camera", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=a9b5be3b6561d8366096a4183e6ea7065bc943d3.js.map